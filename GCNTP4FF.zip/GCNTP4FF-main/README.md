# GCNTP4FF
 A Google Chrome styled new tab page (NTP) for Firefox, built in pure CSS
<hr>

## What is this?
GCNTP4FF (Google Chrome New Tab Page for Firefox) is a userContent.css theme for Firefox that transforms Firefox's new tab page (NTP) into that of Chrome. It's built using pure CSS, and samples elements, colors, and styles directly from Chrome's own NTP CSS file.<br><br>
![GCNTP4FF Preview - Light](https://i.imgur.com/EP1UPEK.png)
![GCNTP4FF Preview - Dark](https://i.imgur.com/F5kZObi.png)

## How to download/install?
It's super easy to install GCNTP4FF. Read below to get started!<br><br>

**NOTE FOR PRE-PROTON USERS:** This has only been tested to work with the new Firefox Proton NTP. If you don't have the new NTP enabled, please follow the steps from this page to enable it, and then return here.<br>
https://winaero.com/firefox-proton-new-tab-page-and-menu/ <br>
(You'll have to scroll down to the **Enable Proton New Tab Page in Firefox** section)<br><br>

**Installing GCNTP4FF**
1. In firefox, visit **about:support**
2. In the **Profile Folder** row, click on the **Open Folder** button. A file explorer/Finder window should open. 
3. Download the latest release of GCNTP4FF from this page: https://github.com/Futur3Sn0w/GCNTP4FF/releases/latest
4. Extract the ZIP file, and copy the **chrome** folder.
5. Paste the **chrome** folder in the **Profile Folder** you opened earlier.
6. Restart Firefox by visiting **about:restartrequired**, and click **Restart Firefox/Nightly**
7. When firefox reopens, you should be able to open a new tab, and see the new look!

## Recommended Settings:
It's HIGHLY recommended that you set these settings on your NTP the same way so that way you get as close to the chrome experience as possible.<br>Configuring your NTP differently than what's shown below can result in a broken page, or may display things incorrectly.<br><br>
![Recommended Settings](https://i.imgur.com/OzjjRVI.png)

## Things to note:
This is a far from perfect implementation, and there are things that I'm still working on improving. However, it's a very close experience to that which you get within Chrome!

## Changelog
**v1.1 - Contextually**<br>
- New context menu for website tiles. Visually identical to chrome.
- Fixed context menus getting cut off by parent box
- Other minor improvements to UI

## Questions? Comments? Bugs? Etc?
If you have any issues using, installing, or viewing GCNTP4FF, feel free to create an issue post here on GitHub, or DM me on Twitter @Futur3Sn0w. I'll be sure to fix it ASAP!
