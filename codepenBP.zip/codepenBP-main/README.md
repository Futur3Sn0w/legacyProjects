# codepenBP
Futur3Sn0w's Codepen.io boilerplate CSS sheets!
<hr>
## Wtf? (Description)
I know it's a bit strange, but ya know. oh well? 😂
No for real though, each sheet is (will be) a specific piece of code that I don't want to have to include everytime I make a specific type of project on codepen. It's for fun; I get lazy. 😂

### body1.css
body{
  margin: 0;
  width: 100vw;
  height: 100vh;
}
