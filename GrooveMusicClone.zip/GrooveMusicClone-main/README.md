# GrooveMusicClone
 Online replica of Microsoft's Groove Music application
