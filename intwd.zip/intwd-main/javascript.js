const windowDiv = document.getElementById("window");
const titlebarDiv = document.getElementById("titleBar");
let root = document.documentElement;

window.onload = function () {
  windowDiv.style.top = localStorage.getItem('winTop');
  windowDiv.style.left = localStorage.getItem('winLeft');
}

titlebarDiv.ondblclick = function () {
    if (localStorage.getItem('winState') == 'Max') {
        windowRestore();
    } else if (localStorage.getItem('winState') == 'Norm') {
        windowMax();
    }
}

function windowMax() {
    windowDiv.style.top = "0";
    windowDiv.style.left = "0";

    windowDiv.style.width = "100vw";
    windowDiv.style.height = "100vh";
    windowDiv.style.borderRadius = "0";

    localStorage.setItem('winState', 'Max');
}

function windowRestore() {
    windowDiv.style.top = localStorage.getItem('winTop');
    windowDiv.style.left = localStorage.getItem('winLeft');

    windowDiv.style.width = "500px"
    windowDiv.style.height = "500px"
    windowDiv.style.borderRadius = "10px";

    localStorage.setItem('winState', 'Norm');
}

dragElement(windowDiv);

function dragElement(elmnt) {
  var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  document.getElementById("titleBar").onmousedown = dragMouseDown;

  function dragMouseDown(e) {
    e = e || window.event;
    e.preventDefault();
    // get the mouse cursor position at startup:
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    // call a function whenever the cursor moves:
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e = e || window.event;
    e.preventDefault();

    // calculate the new cursor position:
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;

    // set the element's new position:
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";

    // extras
    localStorage.setItem('winLeft', elmnt.style.left);
    localStorage.setItem('winTop', elmnt.style.top);
    windowDiv.style.transition = "none";
    windowRestore();
  }

  function closeDragElement() {
    // stop moving when mouse button is released:
    document.onmouseup = null;
    document.onmousemove = null;

    // restore animation when maximizing
    windowDiv.style.transition = ".25s";

    // maximize if top of screen is reached
    if (localStorage.getItem('winTop') < 15 + "px") {
      windowMax();
    }
  }
}