# LightifyWeb
Light mode for open.spotify.com

## Installation
Copy the code from the lightify.css file into Stylish/Stylus/etc and refresh Spotify.
