# MetroMenu
 A recreation of the Windows 8 beta Charms menu that was eventually replaced with the charms bar!
